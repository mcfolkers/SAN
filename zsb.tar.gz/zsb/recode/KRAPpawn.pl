% -*- Mode: Prolog -*-
% King and Pawn vs king in Advice Language 0

% all rules

%trivial_rule :: if pawn_free or king_free
%       then [move_pawn, quick_king].
%other_rule :: if kingdivides
%        then [king_lure1, king_lure2, king_lure3, king_lure4].
else_rule :: if true
        then [pawn_force, advance_king, king_protects, move_king ].

% pieces of advice
% structure:
% advice( NAME, BETTERGOAL, HOLDINGGOAL: USMOVECONSTRAINT:
%               THEMMOVECONSTRAINT

advice( quick_king,
        king_races :
        not pawnlost and not pawnexposed :
        kingdiagfirst :
        nomove ).

advice( king_lure1,
        h_k_step :
        not pawnlost and not pawnexposed :
        kingdiagfirst and king_block:
        nomove ).
advice( king_lure2,
        pawnprotected and not did_not_move_pawn:
        not pawnlost and not pawnexposed :
        pawnmove and not king_block:
        nomove ).
advice( king_lure3,
        h_k_step and pawnprotected :
        not pawnlost and not pawnexposed and pawn_clear :
        kingdiagfirst :
        nomove ).
advice( king_lure4,
        pawnprotected and not did_not_move_king:
        not pawnlost and not pawnexposed :
        kingdiagfirst :
        nomove ).

advice( move_pawn,
        not did_not_move_pawn :
        not pawnlost and not pawnexposed :
	( depth = 0 ) and pawnmove : %then ( depth = 2 ) and legal :
        ( depth = 1 ) and legal).

advice( king_protects,
        not did_not_move_king and king_to_pawn and kingdivides :
	not pawnlost and not pawnexposed and not pawnprotected :
        ( depth = 0 ) and kingdiagfirst :
        nomove ).

advice( move_king,
        okapproachedsquare :
        not pawnlost :
        kingdiagfirst :
        nomove ).

advice( advance_king,
        not did_not_move_king and okapproachedsquare and kingadvances and not kings_close:
        %kingadvances :
        %themtomove and not stalemate :
        not pawnlost :
        ( depth = 0 ) and kingdiagfirst :
        nomove ).

advice( pawn_force,
        not did_not_move_pawn and pawnprotected : %k_p_share_y
        not pawnlost and k_p_share_y :
        (depth=1) and legal and pawnprotected and pawnmove:
        (depth=3) and legal).
